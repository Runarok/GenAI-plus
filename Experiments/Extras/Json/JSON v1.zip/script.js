class JSONCorrector {
    constructor() {
        this.inputText = document.getElementById('inputText');
        this.outputText = document.getElementById('outputText');
        this.statusText = document.getElementById('statusText');
        this.statusIndicator = document.getElementById('statusIndicator');
        this.errorsPanel = document.getElementById('errorsPanel');
        this.errorsList = document.getElementById('errorsList');
        this.inputOverlay = document.getElementById('inputOverlay');
        this.suggestionsModal = document.getElementById('suggestionsModal');
        this.modalBody = document.getElementById('modalBody');
        
        this.currentMode = 'json';
        this.errors = [];
        this.suggestions = [];
        
        this.initEventListeners();
        this.updateStatus('ready', 'Ready');
    }
    
    initEventListeners() {
        // Mode toggle
        document.getElementById('jsonMode').addEventListener('click', () => this.setMode('json'));
        document.getElementById('jsMode').addEventListener('click', () => this.setMode('js'));
        
        // Action buttons
        document.getElementById('analyzeBtn').addEventListener('click', () => this.analyzeInput());
        document.getElementById('clearBtn').addEventListener('click', () => this.clearInput());
        document.getElementById('convertBtn').addEventListener('click', () => this.convertFormat());
        document.getElementById('copyBtn').addEventListener('click', () => this.copyOutput());
        
        // Modal controls
        document.getElementById('modalClose').addEventListener('click', () => this.hideModal());
        document.getElementById('applyAllBtn').addEventListener('click', () => this.applyAllSuggestions());
        document.getElementById('cancelBtn').addEventListener('click', () => this.hideModal());
        
        // Real-time input analysis
        this.inputText.addEventListener('input', () => {
            this.debounce(() => this.analyzeInput(true), 500);
        });
        
        // Click outside modal to close
        this.suggestionsModal.addEventListener('click', (e) => {
            if (e.target === this.suggestionsModal) {
                this.hideModal();
            }
        });
    }
    
    setMode(mode) {
        this.currentMode = mode;
        document.querySelectorAll('.format-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(mode + 'Mode').classList.add('active');
        
        if (this.inputText.value.trim()) {
            this.analyzeInput();
        }
    }
    
    updateStatus(type, message) {
        this.statusText.textContent = message;
        this.statusText.className = `status-text status-${type}`;
        
        if (type === 'analyzing') {
            this.statusText.classList.add('analyzing');
        } else {
            this.statusText.classList.remove('analyzing');
        }
    }
    
    analyzeInput(realTime = false) {
        const input = this.inputText.value.trim();
        
        if (!input) {
            this.clearResults();
            this.updateStatus('ready', 'Ready');
            return;
        }
        
        if (!realTime) {
            this.updateStatus('analyzing', 'Analyzing...');
        }
        
        setTimeout(() => {
            try {
                this.errors = [];
                this.suggestions = [];
                
                const analysis = this.performAnalysis(input);
                this.displayResults(analysis);
                
                if (this.errors.length > 0) {
                    this.updateStatus('error', `${this.errors.length} issue${this.errors.length > 1 ? 's' : ''} found`);
                    this.showErrors();
                } else {
                    this.updateStatus('success', 'Valid syntax');
                    this.hideErrors();
                }
                
            } catch (error) {
                this.updateStatus('error', 'Analysis failed');
                this.outputText.textContent = 'Error: ' + error.message;
            }
        }, realTime ? 0 : 500);
    }
    
    performAnalysis(input) {
        // Remove comments and normalize whitespace
        const cleaned = this.preprocessInput(input);
        
        // Detect missing brackets
        this.detectBracketIssues(cleaned);
        
        // Detect quote issues
        this.detectQuoteIssues(cleaned);
        
        // Detect comma and colon issues
        this.detectPunctuationIssues(cleaned);
        
        // Detect missing keys/values
        this.detectKeyValueIssues(cleaned);
        
        // Try to parse and correct
        let corrected = this.attemptCorrection(cleaned);
        
        return {
            original: input,
            cleaned: cleaned,
            corrected: corrected,
            isValid: this.errors.length === 0
        };
    }
    
    preprocessInput(input) {
        // Remove single-line comments
        let cleaned = input.replace(/\/\/.*$/gm, '');
        
        // Remove multi-line comments
        cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//g, '');
        
        // Normalize whitespace but preserve structure
        return cleaned.trim();
    }
    
    detectBracketIssues(input) {
        const brackets = [];
        const openBrackets = '({[';
        const closeBrackets = ')}]';
        const pairs = { '(': ')', '{': '}', '[': ']' };
        
        for (let i = 0; i < input.length; i++) {
            const char = input[i];
            
            if (openBrackets.includes(char)) {
                brackets.push({ char, pos: i });
            } else if (closeBrackets.includes(char)) {
                if (brackets.length === 0) {
                    this.addError('bracket', `Unexpected closing bracket '${char}'`, i, 
                        `Remove the extra '${char}' or add a matching opening bracket`);
                } else {
                    const last = brackets.pop();
                    if (pairs[last.char] !== char) {
                        this.addError('bracket', `Mismatched brackets: expected '${pairs[last.char]}' but found '${char}'`, i,
                            `Change '${char}' to '${pairs[last.char]}' or fix the opening bracket`);
                    }
                }
            }
        }
        
        // Check for unclosed brackets
        brackets.forEach(bracket => {
            this.addError('bracket', `Unclosed bracket '${bracket.char}'`, bracket.pos,
                `Add closing '${pairs[bracket.char]}' at the end`);
        });
    }
    
    detectQuoteIssues(input) {
        let inString = false;
        let stringChar = null;
        let escaped = false;
        
        for (let i = 0; i < input.length; i++) {
            const char = input[i];
            const prevChar = i > 0 ? input[i - 1] : null;
            
            if (escaped) {
                escaped = false;
                continue;
            }
            
            if (char === '\\') {
                escaped = true;
                continue;
            }
            
            if ((char === '"' || char === "'") && !inString) {
                inString = true;
                stringChar = char;
            } else if (char === stringChar && inString) {
                inString = false;
                stringChar = null;
            }
        }
        
        if (inString) {
            this.addError('quote', `Unclosed string starting with '${stringChar}'`, 0,
                `Add closing '${stringChar}' at the end of the string`);
        }
        
        // Check for unquoted keys in JSON mode
        if (this.currentMode === 'json') {
            this.detectUnquotedKeys(input);
        }
    }
    
    detectUnquotedKeys(input) {
        // Look for unquoted property names
        const keyPattern = /([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g;
        let match;
        
        while ((match = keyPattern.exec(input)) !== null) {
            const key = match[2];
            const pos = match.index + match[1].length;
            
            this.addError('quote', `Unquoted key '${key}' in JSON`, pos,
                `Wrap key in double quotes: "${key}"`);
        }
    }
    
    detectPunctuationIssues(input) {
        // Check for missing commas
        const lines = input.split('\n');
        
        lines.forEach((line, lineIndex) => {
            const trimmed = line.trim();
            
            // Check for missing comma after object/array elements
            if (trimmed.match(/[}\]]\s*[{\["a-zA-Z]/)) {
                this.addError('comma', 'Missing comma between elements', lineIndex,
                    'Add comma after the closing bracket');
            }
            
            // Check for trailing commas in JSON mode
            if (this.currentMode === 'json' && trimmed.match(/,\s*[}\]]/)) {
                this.addError('comma', 'Trailing comma not allowed in JSON', lineIndex,
                    'Remove the trailing comma');
            }
            
            // Check for missing colons
            if (trimmed.match(/"[^"]*"\s+[^:]/)) {
                this.addError('colon', 'Missing colon after key', lineIndex,
                    'Add colon after the key');
            }
        });
    }
    
    detectKeyValueIssues(input) {
        // Check for keys without values
        const colonPattern = /:\s*[,}]/g;
        let match;
        
        while ((match = colonPattern.exec(input)) !== null) {
            this.addError('value', 'Missing value after colon', match.index,
                'Add a value after the colon (string, number, boolean, null, object, or array)');
        }
    }
    
    attemptCorrection(input) {
        let corrected = input;
        
        try {
            // Try basic corrections
            corrected = this.fixCommonIssues(corrected);
            
            // Try to parse
            if (this.currentMode === 'json') {
                JSON.parse(corrected);
            } else {
                eval('(' + corrected + ')');
            }
            
            return this.formatOutput(corrected);
        } catch (error) {
            // If parsing fails, return formatted original with syntax highlighting
            return this.formatOutput(input);
        }
    }
    
    fixCommonIssues(input) {
        let fixed = input;
        
        // Fix unquoted keys in JSON mode
        if (this.currentMode === 'json') {
            fixed = fixed.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');
        }
        
        // Fix single quotes to double quotes in JSON mode
        if (this.currentMode === 'json') {
            fixed = fixed.replace(/'([^']*)'/g, '"$1"');
        }
        
        // Remove trailing commas in JSON mode
        if (this.currentMode === 'json') {
            fixed = fixed.replace(/,(\s*[}\]])/g, '$1');
        }
        
        return fixed;
    }
    
    formatOutput(text) {
        try {
            let parsed;
            
            if (this.currentMode === 'json') {
                parsed = JSON.parse(text);
                return JSON.stringify(parsed, null, 2);
            } else {
                parsed = eval('(' + text + ')');
                return this.formatJavaScript(parsed);
            }
        } catch (error) {
            return this.applySyntaxHighlighting(text);
        }
    }
    
    formatJavaScript(obj, indent = 0) {
        const spaces = '  '.repeat(indent);
        
        if (obj === null) return 'null';
        if (obj === undefined) return 'undefined';
        if (typeof obj === 'string') return `'${obj}'`;
        if (typeof obj === 'number' || typeof obj === 'boolean') return String(obj);
        
        if (Array.isArray(obj)) {
            if (obj.length === 0) return '[]';
            const items = obj.map(item => this.formatJavaScript(item, indent + 1));
            return '[\n' + items.map(item => '  ' + spaces + item).join(',\n') + '\n' + spaces + ']';
        }
        
        if (typeof obj === 'object') {
            const keys = Object.keys(obj);
            if (keys.length === 0) return '{}';
            const items = keys.map(key => {
                const value = this.formatJavaScript(obj[key], indent + 1);
                return `${key}: ${value}`;
            });
            return '{\n' + items.map(item => '  ' + spaces + item).join(',\n') + '\n' + spaces + '}';
        }
        
        return String(obj);
    }
    
    applySyntaxHighlighting(text) {
        // Basic syntax highlighting for display
        return text
            .replace(/"([^"]*)":/g, '<span class="json-key">"$1"</span>:')
            .replace(/"([^"]*)"/g, '<span class="json-string">"$1"</span>')
            .replace(/\b(\d+\.?\d*)\b/g, '<span class="json-number">$1</span>')
            .replace(/\b(true|false)\b/g, '<span class="json-boolean">$1</span>')
            .replace(/\bnull\b/g, '<span class="json-null">null</span>')
            .replace(/([{}[\]:,])/g, '<span class="json-punctuation">$1</span>');
    }
    
    addError(type, message, position, suggestion) {
        this.errors.push({
            type,
            message,
            position,
            suggestion,
            id: Date.now() + Math.random()
        });
        
        if (suggestion) {
            this.suggestions.push({
                type,
                message,
                suggestion,
                position,
                id: Date.now() + Math.random()
            });
        }
    }
    
    displayResults(analysis) {
        if (analysis.corrected) {
            this.outputText.innerHTML = this.applySyntaxHighlighting(analysis.corrected);
        } else {
            this.outputText.textContent = analysis.original;
        }
    }
    
    showErrors() {
        this.errorsPanel.classList.add('show');
        this.errorsList.innerHTML = '';
        
        this.errors.forEach(error => {
            const errorElement = this.createErrorElement(error);
            this.errorsList.appendChild(errorElement);
        });
    }
    
    hideErrors() {
        this.errorsPanel.classList.remove('show');
    }
    
    createErrorElement(error) {
        const div = document.createElement('div');
        div.className = 'error-item';
        
        div.innerHTML = `
            <div class="error-type">${error.type.toUpperCase()} ERROR</div>
            <div class="error-message">${error.message}</div>
            ${error.suggestion ? `
                <div class="error-suggestion">💡 ${error.suggestion}</div>
                <div class="suggestion-buttons">
                    <button class="suggestion-btn accept-btn" onclick="corrector.applySuggestion('${error.id}')">
                        Apply
                    </button>
                    <button class="suggestion-btn reject-btn" onclick="corrector.rejectSuggestion('${error.id}')">
                        Ignore
                    </button>
                </div>
            ` : ''}
        `;
        
        return div;
    }
    
    applySuggestion(errorId) {
        const error = this.errors.find(e => e.id.toString() === errorId);
        if (!error) return;
        
        // Apply the suggestion to the input
        let input = this.inputText.value;
        
        // Simple correction based on error type
        switch (error.type) {
            case 'quote':
                if (error.message.includes('Unquoted key')) {
                    const key = error.message.match(/'([^']*)'/)[1];
                    input = input.replace(new RegExp(`(\\s)${key}(\\s*:)`, 'g'), `$1"${key}"$2`);
                }
                break;
            case 'comma':
                if (error.message.includes('Trailing comma')) {
                    input = input.replace(/,(\s*[}\]])/g, '$1');
                }
                break;
        }
        
        this.inputText.value = input;
        this.analyzeInput();
    }
    
    rejectSuggestion(errorId) {
        this.errors = this.errors.filter(e => e.id.toString() !== errorId);
        this.showErrors();
    }
    
    convertFormat() {
        const input = this.inputText.value.trim();
        if (!input) return;
        
        try {
            let converted;
            
            if (this.currentMode === 'json') {
                // Convert JSON to JavaScript
                const parsed = JSON.parse(input);
                converted = this.formatJavaScript(parsed);
                this.setMode('js');
            } else {
                // Convert JavaScript to JSON
                const parsed = eval('(' + input + ')');
                converted = JSON.stringify(parsed, null, 2);
                this.setMode('json');
            }
            
            this.inputText.value = converted;
            this.analyzeInput();
            
        } catch (error) {
            this.updateStatus('error', 'Conversion failed: ' + error.message);
        }
    }
    
    clearInput() {
        this.inputText.value = '';
        this.clearResults();
        this.updateStatus('ready', 'Ready');
    }
    
    clearResults() {
        this.outputText.textContent = '';
        this.hideErrors();
        this.errors = [];
        this.suggestions = [];
    }
    
    copyOutput() {
        const text = this.outputText.textContent;
        if (!text) return;
        
        navigator.clipboard.writeText(text).then(() => {
            // Visual feedback
            const btn = document.getElementById('copyBtn');
            const originalHTML = btn.innerHTML;
            btn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
            `;
            btn.style.color = '#10b981';
            
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.style.color = '';
            }, 1000);
        });
    }
    
    showModal() {
        this.suggestionsModal.classList.add('show');
        this.populateModal();
    }
    
    hideModal() {
        this.suggestionsModal.classList.remove('show');
    }
    
    populateModal() {
        this.modalBody.innerHTML = '';
        
        this.suggestions.forEach(suggestion => {
            const div = document.createElement('div');
            div.className = 'error-item';
            div.innerHTML = `
                <div class="error-type">${suggestion.type.toUpperCase()}</div>
                <div class="error-message">${suggestion.message}</div>
                <div class="error-suggestion">${suggestion.suggestion}</div>
            `;
            this.modalBody.appendChild(div);
        });
    }
    
    applyAllSuggestions() {
        this.suggestions.forEach(suggestion => {
            this.applySuggestion(suggestion.id);
        });
        this.hideModal();
    }
    
    debounce(func, wait) {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(func, wait);
    }
}

// Initialize the corrector when the page loads
let corrector;
document.addEventListener('DOMContentLoaded', () => {
    corrector = new JSONCorrector();
});