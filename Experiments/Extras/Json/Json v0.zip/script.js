class JSONCorrector {
    constructor() {
        this.inputText = document.getElementById('inputText');
        this.outputText = document.getElementById('outputText');
        this.statusText = document.getElementById('statusText');
        this.statusDot = document.getElementById('statusDot');
        this.errorOverlay = document.getElementById('errorOverlay');
        this.tooltip = document.getElementById('tooltip');
        this.lineNumbers = document.getElementById('lineNumbers');
        this.outputLineNumbers = document.getElementById('outputLineNumbers');
        this.quickFixesPanel = document.getElementById('quickFixesPanel');
        this.fixesList = document.getElementById('fixesList');
        this.fileInput = document.getElementById('fileInput');
        
        // Stats elements
        this.lineCount = document.getElementById('lineCount');
        this.charCount = document.getElementById('charCount');
        this.issueCount = document.getElementById('issueCount');
        this.sizeCount = document.getElementById('sizeCount');
        
        this.currentMode = 'json';
        this.errors = [];
        this.debounceTimer = null;
        
        this.initEventListeners();
        this.updateStatus('ready', 'Ready');
        this.updateLineNumbers();
    }
    
    initEventListeners() {
        // Mode toggle
        document.getElementById('jsonMode').addEventListener('click', () => this.setMode('json'));
        document.getElementById('jsMode').addEventListener('click', () => this.setMode('js'));
        
        // File upload
        this.fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
        
        // Action buttons
        document.getElementById('analyzeBtn').addEventListener('click', () => this.analyzeInput());
        document.getElementById('clearBtn').addEventListener('click', () => this.clearInput());
        document.getElementById('convertBtn').addEventListener('click', () => this.convertFormat());
        document.getElementById('formatBtn').addEventListener('click', () => this.formatCode());
        document.getElementById('copyBtn').addEventListener('click', () => this.copyOutput());
        document.getElementById('applyAllBtn').addEventListener('click', () => this.applyAllFixes());
        
        // Real-time input analysis
        this.inputText.addEventListener('input', () => {
            this.updateLineNumbers();
            this.updateStats();
            this.debounce(() => this.analyzeInput(true), 300);
        });
        
        this.inputText.addEventListener('scroll', () => this.syncScroll());
        
        // Error overlay interactions
        this.errorOverlay.addEventListener('mouseover', (e) => this.showTooltip(e));
        this.errorOverlay.addEventListener('mouseout', () => this.hideTooltip());
        this.errorOverlay.addEventListener('click', (e) => this.handleErrorClick(e));
    }
    
    setMode(mode) {
        this.currentMode = mode;
        document.querySelectorAll('.format-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(mode + 'Mode').classList.add('active');
        
        if (this.inputText.value.trim()) {
            this.analyzeInput();
        }
    }
    
    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            this.inputText.value = e.target.result;
            this.updateLineNumbers();
            this.updateStats();
            
            // Auto-detect format
            const content = e.target.result.trim();
            if (content.startsWith('{') || content.startsWith('[')) {
                this.setMode('json');
            } else {
                this.setMode('js');
            }
            
            this.analyzeInput();
        };
        reader.readAsText(file);
        
        // Reset file input
        event.target.value = '';
    }
    
    updateStatus(type, message) {
        this.statusText.textContent = message;
        this.statusDot.className = `status-dot ${type}`;
    }
    
    updateLineNumbers() {
        const lines = this.inputText.value.split('\n');
        const lineNumbersHtml = lines.map((_, index) => index + 1).join('\n');
        this.lineNumbers.textContent = lineNumbersHtml;
        
        // Update output line numbers
        const outputLines = this.outputText.textContent.split('\n');
        const outputLineNumbersHtml = outputLines.map((_, index) => index + 1).join('\n');
        this.outputLineNumbers.textContent = outputLineNumbersHtml;
    }
    
    updateStats() {
        const content = this.inputText.value;
        const lines = content.split('\n').length;
        const chars = content.length;
        const bytes = new Blob([content]).size;
        
        this.lineCount.textContent = lines;
        this.charCount.textContent = chars.toLocaleString();
        this.issueCount.textContent = this.errors.length;
        this.sizeCount.textContent = this.formatBytes(bytes);
    }
    
    formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }
    
    syncScroll() {
        this.errorOverlay.scrollTop = this.inputText.scrollTop;
        this.errorOverlay.scrollLeft = this.inputText.scrollLeft;
        this.lineNumbers.scrollTop = this.inputText.scrollTop;
    }
    
    analyzeInput(realTime = false) {
        const input = this.inputText.value.trim();
        
        if (!input) {
            this.clearResults();
            this.updateStatus('ready', 'Ready');
            return;
        }
        
        if (!realTime) {
            this.updateStatus('analyzing', 'Analyzing...');
        }
        
        setTimeout(() => {
            try {
                this.errors = [];
                const analysis = this.performAnalysis(input);
                this.displayResults(analysis);
                this.updateErrorOverlay();
                this.updateQuickFixes();
                this.updateStats();
                
                if (this.errors.length > 0) {
                    this.updateStatus('error', `${this.errors.length} issue${this.errors.length > 1 ? 's' : ''} found`);
                } else {
                    this.updateStatus('success', 'Valid syntax');
                }
                
            } catch (error) {
                this.updateStatus('error', 'Analysis failed');
                this.outputText.textContent = 'Error: ' + error.message;
            }
        }, realTime ? 0 : 300);
    }
    
    performAnalysis(input) {
        // Clean input
        const cleaned = this.preprocessInput(input);
        
        // Perform various checks
        this.detectBracketIssues(cleaned);
        this.detectQuoteIssues(cleaned);
        this.detectPunctuationIssues(cleaned);
        this.detectKeyValueIssues(cleaned);
        this.detectTrailingCommas(cleaned);
        
        // Try to parse and correct
        let corrected = this.attemptCorrection(cleaned);
        
        return {
            original: input,
            cleaned: cleaned,
            corrected: corrected,
            isValid: this.errors.length === 0
        };
    }
    
    preprocessInput(input) {
        // Remove single-line comments
        let cleaned = input.replace(/\/\/.*$/gm, '');
        
        // Remove multi-line comments
        cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//g, '');
        
        return cleaned.trim();
    }
    
    detectBracketIssues(input) {
        const brackets = [];
        const openBrackets = '({[';
        const closeBrackets = ')}]';
        const pairs = { '(': ')', '{': '}', '[': ']' };
        
        for (let i = 0; i < input.length; i++) {
            const char = input[i];
            
            if (openBrackets.includes(char)) {
                brackets.push({ char, pos: i });
            } else if (closeBrackets.includes(char)) {
                if (brackets.length === 0) {
                    this.addError('error', 'bracket', `Unexpected closing bracket '${char}'`, i, 
                        `Remove the extra '${char}' or add a matching opening bracket`);
                } else {
                    const last = brackets.pop();
                    if (pairs[last.char] !== char) {
                        this.addError('error', 'bracket', `Mismatched brackets: expected '${pairs[last.char]}' but found '${char}'`, i,
                            `Change '${char}' to '${pairs[last.char]}' or fix the opening bracket`);
                    }
                }
            }
        }
        
        // Check for unclosed brackets
        brackets.forEach(bracket => {
            this.addError('error', 'bracket', `Unclosed bracket '${bracket.char}'`, bracket.pos,
                `Add closing '${pairs[bracket.char]}' at the end`);
        });
    }
    
    detectQuoteIssues(input) {
        let inString = false;
        let stringChar = null;
        let escaped = false;
        
        for (let i = 0; i < input.length; i++) {
            const char = input[i];
            
            if (escaped) {
                escaped = false;
                continue;
            }
            
            if (char === '\\') {
                escaped = true;
                continue;
            }
            
            if ((char === '"' || char === "'") && !inString) {
                inString = true;
                stringChar = char;
            } else if (char === stringChar && inString) {
                inString = false;
                stringChar = null;
            }
        }
        
        if (inString) {
            this.addError('error', 'quote', `Unclosed string starting with '${stringChar}'`, 0,
                `Add closing '${stringChar}' at the end of the string`);
        }
        
        // Check for unquoted keys in JSON mode
        if (this.currentMode === 'json') {
            this.detectUnquotedKeys(input);
        }
    }
    
    detectUnquotedKeys(input) {
        const keyPattern = /([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g;
        let match;
        
        while ((match = keyPattern.exec(input)) !== null) {
            const key = match[2];
            const pos = match.index + match[1].length;
            
            this.addError('warning', 'quote', `Unquoted key '${key}' in JSON`, pos,
                `Wrap key in double quotes: "${key}"`);
        }
    }
    
    detectPunctuationIssues(input) {
        // Check for missing commas between elements
        const missingCommaPattern = /[}\]]\s*[{\["a-zA-Z]/g;
        let match;
        
        while ((match = missingCommaPattern.exec(input)) !== null) {
            this.addError('error', 'comma', 'Missing comma between elements', match.index,
                'Add comma after the closing bracket');
        }
        
        // Check for missing colons
        const missingColonPattern = /"[^"]*"\s+[^:]/g;
        while ((match = missingColonPattern.exec(input)) !== null) {
            this.addError('error', 'colon', 'Missing colon after key', match.index,
                'Add colon after the key');
        }
    }
    
    detectKeyValueIssues(input) {
        // Check for keys without values
        const emptyValuePattern = /:\s*[,}]/g;
        let match;
        
        while ((match = emptyValuePattern.exec(input)) !== null) {
            this.addError('warning', 'value', 'Missing value after colon', match.index,
                'Add a value after the colon (string, number, boolean, null, object, or array)');
        }
    }
    
    detectTrailingCommas(input) {
        if (this.currentMode === 'json') {
            const trailingCommaPattern = /,(\s*[}\]])/g;
            let match;
            
            while ((match = trailingCommaPattern.exec(input)) !== null) {
                this.addError('error', 'comma', 'Trailing comma not allowed in JSON', match.index,
                    'Remove the trailing comma');
            }
        }
    }
    
    attemptCorrection(input) {
        let corrected = input;
        
        try {
            // Apply automatic fixes
            corrected = this.applyAutomaticFixes(corrected);
            
            // Try to parse
            if (this.currentMode === 'json') {
                JSON.parse(corrected);
            } else {
                eval('(' + corrected + ')');
            }
            
            return this.formatOutput(corrected);
        } catch (error) {
            return this.formatOutput(input);
        }
    }
    
    applyAutomaticFixes(input) {
        let fixed = input;
        
        // Fix unquoted keys in JSON mode
        if (this.currentMode === 'json') {
            fixed = fixed.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');
            
            // Fix single quotes to double quotes
            fixed = fixed.replace(/'([^']*)'/g, '"$1"');
            
            // Remove trailing commas
            fixed = fixed.replace(/,(\s*[}\]])/g, '$1');
        }
        
        return fixed;
    }
    
    formatOutput(text) {
        try {
            let parsed;
            
            if (this.currentMode === 'json') {
                parsed = JSON.parse(text);
                return JSON.stringify(parsed, null, 2);
            } else {
                parsed = eval('(' + text + ')');
                return this.formatJavaScript(parsed);
            }
        } catch (error) {
            return this.applySyntaxHighlighting(text);
        }
    }
    
    formatJavaScript(obj, indent = 0) {
        const spaces = '  '.repeat(indent);
        
        if (obj === null) return 'null';
        if (obj === undefined) return 'undefined';
        if (typeof obj === 'string') return `'${obj.replace(/'/g, "\\'")}'`;
        if (typeof obj === 'number' || typeof obj === 'boolean') return String(obj);
        
        if (Array.isArray(obj)) {
            if (obj.length === 0) return '[]';
            const items = obj.map(item => this.formatJavaScript(item, indent + 1));
            return '[\n' + items.map(item => '  ' + spaces + item).join(',\n') + '\n' + spaces + ']';
        }
        
        if (typeof obj === 'object') {
            const keys = Object.keys(obj);
            if (keys.length === 0) return '{}';
            const items = keys.map(key => {
                const value = this.formatJavaScript(obj[key], indent + 1);
                const keyStr = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(key) ? key : `'${key}'`;
                return `${keyStr}: ${value}`;
            });
            return '{\n' + items.map(item => '  ' + spaces + item).join(',\n') + '\n' + spaces + '}';
        }
        
        return String(obj);
    }
    
    applySyntaxHighlighting(text) {
        return text
            .replace(/"([^"]*)":/g, '<span class="json-key">"$1"</span>:')
            .replace(/"([^"]*)"/g, '<span class="json-string">"$1"</span>')
            .replace(/\b(\d+\.?\d*)\b/g, '<span class="json-number">$1</span>')
            .replace(/\b(true|false)\b/g, '<span class="json-boolean">$1</span>')
            .replace(/\bnull\b/g, '<span class="json-null">null</span>')
            .replace(/([{}[\]:,])/g, '<span class="json-punctuation">$1</span>');
    }
    
    addError(severity, type, message, position, suggestion) {
        this.errors.push({
            severity,
            type,
            message,
            position,
            suggestion,
            id: Date.now() + Math.random()
        });
    }
    
    displayResults(analysis) {
        if (analysis.corrected) {
            this.outputText.innerHTML = this.applySyntaxHighlighting(analysis.corrected);
        } else {
            this.outputText.textContent = analysis.original;
        }
        this.updateLineNumbers();
    }
    
    updateErrorOverlay() {
        const input = this.inputText.value;
        let overlayContent = input;
        
        // Sort errors by position (reverse order to avoid position shifts)
        const sortedErrors = [...this.errors].sort((a, b) => b.position - a.position);
        
        sortedErrors.forEach(error => {
            const pos = error.position;
            const char = input[pos];
            if (char) {
                const before = overlayContent.substring(0, pos);
                const after = overlayContent.substring(pos + 1);
                overlayContent = before + 
                    `<span class="error-highlight ${error.severity}" data-error-id="${error.id}">${char}</span>` + 
                    after;
            }
        });
        
        this.errorOverlay.innerHTML = overlayContent;
    }
    
    updateQuickFixes() {
        if (this.errors.length === 0) {
            this.quickFixesPanel.classList.remove('show');
            return;
        }
        
        this.quickFixesPanel.classList.add('show');
        this.fixesList.innerHTML = '';
        
        this.errors.forEach(error => {
            const fixElement = this.createFixElement(error);
            this.fixesList.appendChild(fixElement);
        });
    }
    
    createFixElement(error) {
        const div = document.createElement('div');
        div.className = 'fix-item fade-in';
        
        div.innerHTML = `
            <div class="fix-header">
                <span class="fix-type ${error.severity}">${error.type}</span>
            </div>
            <div class="fix-message">${error.message}</div>
            ${error.suggestion ? `
                <div class="fix-suggestion">💡 ${error.suggestion}</div>
                <div class="fix-actions">
                    <button class="fix-btn accept" onclick="corrector.applyFix('${error.id}')">
                        Apply Fix
                    </button>
                    <button class="fix-btn reject" onclick="corrector.dismissFix('${error.id}')">
                        Dismiss
                    </button>
                </div>
            ` : ''}
        `;
        
        return div;
    }
    
    showTooltip(event) {
        const target = event.target;
        if (!target.classList.contains('error-highlight')) return;
        
        const errorId = target.dataset.errorId;
        const error = this.errors.find(e => e.id.toString() === errorId);
        if (!error) return;
        
        this.tooltip.innerHTML = `
            <div class="tooltip-header">${error.type.toUpperCase()} ${error.severity.toUpperCase()}</div>
            <div class="tooltip-message">${error.message}</div>
            ${error.suggestion ? `<div class="tooltip-suggestion">💡 ${error.suggestion}</div>` : ''}
        `;
        
        const rect = target.getBoundingClientRect();
        const containerRect = this.inputText.getBoundingClientRect();
        
        this.tooltip.style.left = (rect.left - containerRect.left + 20) + 'px';
        this.tooltip.style.top = (rect.bottom - containerRect.top + 5) + 'px';
        this.tooltip.classList.add('show');
    }
    
    hideTooltip() {
        this.tooltip.classList.remove('show');
    }
    
    handleErrorClick(event) {
        const target = event.target;
        if (!target.classList.contains('error-highlight')) return;
        
        const errorId = target.dataset.errorId;
        this.applyFix(errorId);
    }
    
    applyFix(errorId) {
        const error = this.errors.find(e => e.id.toString() === errorId);
        if (!error || !error.suggestion) return;
        
        let input = this.inputText.value;
        
        // Apply specific fixes based on error type
        switch (error.type) {
            case 'quote':
                if (error.message.includes('Unquoted key')) {
                    const keyMatch = error.message.match(/'([^']*)'/);
                    if (keyMatch) {
                        const key = keyMatch[1];
                        input = input.replace(new RegExp(`(\\s)${key}(\\s*:)`, 'g'), `$1"${key}"$2`);
                    }
                }
                break;
            case 'comma':
                if (error.message.includes('Trailing comma')) {
                    input = input.replace(/,(\s*[}\]])/g, '$1');
                } else if (error.message.includes('Missing comma')) {
                    // Add comma at the error position
                    const pos = error.position;
                    input = input.substring(0, pos + 1) + ',' + input.substring(pos + 1);
                }
                break;
        }
        
        this.inputText.value = input;
        this.updateLineNumbers();
        this.analyzeInput();
    }
    
    dismissFix(errorId) {
        this.errors = this.errors.filter(e => e.id.toString() !== errorId);
        this.updateQuickFixes();
        this.updateErrorOverlay();
        this.updateStats();
    }
    
    applyAllFixes() {
        // Apply all fixes in reverse order to maintain positions
        const fixableErrors = this.errors.filter(e => e.suggestion);
        fixableErrors.reverse().forEach(error => {
            this.applyFix(error.id.toString());
        });
    }
    
    convertFormat() {
        const input = this.inputText.value.trim();
        if (!input) return;
        
        try {
            let converted;
            
            if (this.currentMode === 'json') {
                // Convert JSON to JavaScript
                const parsed = JSON.parse(input);
                converted = this.formatJavaScript(parsed);
                this.setMode('js');
            } else {
                // Convert JavaScript to JSON
                const parsed = eval('(' + input + ')');
                converted = JSON.stringify(parsed, null, 2);
                this.setMode('json');
            }
            
            this.inputText.value = converted;
            this.updateLineNumbers();
            this.analyzeInput();
            
        } catch (error) {
            this.updateStatus('error', 'Conversion failed: ' + error.message);
        }
    }
    
    formatCode() {
        const input = this.inputText.value.trim();
        if (!input) return;
        
        try {
            let formatted;
            
            if (this.currentMode === 'json') {
                const parsed = JSON.parse(input);
                formatted = JSON.stringify(parsed, null, 2);
            } else {
                const parsed = eval('(' + input + ')');
                formatted = this.formatJavaScript(parsed);
            }
            
            this.inputText.value = formatted;
            this.updateLineNumbers();
            this.analyzeInput();
            
        } catch (error) {
            this.updateStatus('error', 'Format failed: ' + error.message);
        }
    }
    
    clearInput() {
        this.inputText.value = '';
        this.clearResults();
        this.updateStatus('ready', 'Ready');
        this.updateLineNumbers();
        this.updateStats();
    }
    
    clearResults() {
        this.outputText.textContent = '';
        this.errorOverlay.innerHTML = '';
        this.quickFixesPanel.classList.remove('show');
        this.errors = [];
        this.hideTooltip();
    }
    
    copyOutput() {
        const text = this.outputText.textContent;
        if (!text) return;
        
        navigator.clipboard.writeText(text).then(() => {
            const btn = document.getElementById('copyBtn');
            const originalHTML = btn.innerHTML;
            btn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
            `;
            btn.style.color = '#10b981';
            
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.style.color = '';
            }, 1000);
        });
    }
    
    debounce(func, wait) {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(func, wait);
    }
}

// Initialize the corrector when the page loads
let corrector;
document.addEventListener('DOMContentLoaded', () => {
    corrector = new JSONCorrector();
});