class JSONJSCorrector {
    constructor() {
        this.currentMode = 'json';
        this.currentInput = '';
        this.issues = [];
        this.debounceTimer = null;
        
        this.initializeElements();
        this.bindEvents();
        this.updateStats();
    }

    initializeElements() {
        this.inputEditor = document.getElementById('inputEditor');
        this.outputContent = document.getElementById('outputContent');
        this.inputLineNumbers = document.getElementById('inputLineNumbers');
        this.outputLineNumbers = document.getElementById('outputLineNumbers');
        this.fileInput = document.getElementById('fileInput');
        this.dropZone = document.getElementById('dropZone');
        
        // Stats elements
        this.lineCount = document.getElementById('lineCount');
        this.charCount = document.getElementById('charCount');
        this.issueCount = document.getElementById('issueCount');
        this.fileSize = document.getElementById('fileSize');
        this.statusDot = document.getElementById('statusDot');
        this.statusText = document.getElementById('statusText');
        
        // Issues elements
        this.issuesList = document.getElementById('issuesList');
        this.applyAllBtn = document.getElementById('applyAllBtn');
    }

    bindEvents() {
        // Mode toggle
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchMode(e.target.dataset.mode));
        });

        // Input editor
        this.inputEditor.addEventListener('input', (e) => this.handleInput(e));
        this.inputEditor.addEventListener('scroll', (e) => this.syncLineNumbers(e));

        // Buttons
        document.getElementById('clearBtn').addEventListener('click', () => this.clearInput());
        document.getElementById('formatBtn').addEventListener('click', () => this.formatCode());
        document.getElementById('copyBtn').addEventListener('click', () => this.copyOutput());
        this.applyAllBtn.addEventListener('click', () => this.applyAllFixes());

        // File upload
        this.fileInput.addEventListener('change', (e) => this.handleFileUpload(e));

        // Drag and drop
        document.addEventListener('dragover', (e) => this.handleDragOver(e));
        document.addEventListener('drop', (e) => this.handleDrop(e));
        document.addEventListener('dragenter', (e) => this.handleDragEnter(e));
        document.addEventListener('dragleave', (e) => this.handleDragLeave(e));

        // Section toggles
        document.querySelectorAll('.section-header').forEach(header => {
            header.addEventListener('click', (e) => this.toggleSection(e));
        });
    }

    switchMode(mode) {
        this.currentMode = mode;
        
        // Update active button
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });

        // Update placeholder
        this.inputEditor.placeholder = mode === 'json' 
            ? 'Paste your JSON here...'
            : 'Paste your JavaScript object here...';

        // Re-analyze current input
        this.analyzeCode();
    }

    handleInput(e) {
        this.currentInput = e.target.value;
        this.updateLineNumbers('input');
        
        // Debounced analysis
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => {
            this.analyzeCode();
        }, 300);
        
        this.updateStats();
    }

    updateLineNumbers(type) {
        const content = type === 'input' ? this.currentInput : this.outputContent.textContent;
        const lines = content.split('\n').length;
        const numbersElement = type === 'input' ? this.inputLineNumbers : this.outputLineNumbers;
        
        numbersElement.innerHTML = Array.from({length: lines}, (_, i) => i + 1).join('\n');
    }

    syncLineNumbers(e) {
        const scrollTop = e.target.scrollTop;
        this.inputLineNumbers.scrollTop = scrollTop;
    }

    analyzeCode() {
        this.setStatus('analyzing', 'Analyzing...');
        
        if (!this.currentInput.trim()) {
            this.outputContent.textContent = 'Ready...';
            this.issues = [];
            this.updateIssues();
            this.setStatus('ready', 'Ready');
            return;
        }

        try {
            const result = this.processCode(this.currentInput);
            this.outputContent.innerHTML = this.highlightSyntax(result.output);
            this.issues = result.issues;
            this.updateIssues();
            this.updateLineNumbers('output');
            
            if (this.issues.length > 0) {
                this.setStatus('error', `${this.issues.length} issue(s) found`);
            } else {
                this.setStatus('success', 'Valid syntax');
            }
        } catch (error) {
            this.outputContent.textContent = `Error: ${error.message}`;
            this.setStatus('error', 'Parse error');
        }
    }

    processCode(input) {
        const issues = [];
        let processedInput = input.trim();

        // Detect and fix common issues
        const fixes = this.detectIssues(processedInput);
        issues.push(...fixes);

        let output;
        
        if (this.currentMode === 'json') {
            // Try to parse as JSON and convert to JavaScript if needed
            try {
                const parsed = JSON.parse(processedInput);
                output = JSON.stringify(parsed, null, 2);
            } catch (e) {
                // Try to fix common JSON issues and parse again
                const fixedInput = this.autoFixJSON(processedInput);
                try {
                    const parsed = JSON.parse(fixedInput);
                    output = JSON.stringify(parsed, null, 2);
                    if (fixedInput !== processedInput) {
                        issues.push({
                            severity: 'warning',
                            description: 'Auto-fixed JSON syntax',
                            fix: () => this.inputEditor.value = fixedInput
                        });
                    }
                } catch (e2) {
                    output = `Invalid JSON: ${e2.message}`;
                    issues.push({
                        severity: 'error',
                        description: e2.message,
                        fix: null
                    });
                }
            }
        } else {
            // JavaScript mode - try to evaluate and stringify
            try {
                const func = new Function('return ' + processedInput);
                const result = func();
                output = this.formatJavaScript(result);
            } catch (e) {
                output = `Invalid JavaScript: ${e.message}`;
                issues.push({
                    severity: 'error',
                    description: e.message,
                    fix: null
                });
            }
        }

        return { output, issues };
    }

    detectIssues(input) {
        const issues = [];
        
        // Check for unmatched brackets
        const brackets = { '{': '}', '[': ']', '(': ')' };
        const stack = [];
        let inString = false;
        let stringChar = '';
        
        for (let i = 0; i < input.length; i++) {
            const char = input[i];
            const prevChar = i > 0 ? input[i - 1] : '';
            
            if ((char === '"' || char === "'") && prevChar !== '\\') {
                if (!inString) {
                    inString = true;
                    stringChar = char;
                } else if (char === stringChar) {
                    inString = false;
                    stringChar = '';
                }
            }
            
            if (!inString) {
                if (brackets[char]) {
                    stack.push({ char, pos: i });
                } else if (Object.values(brackets).includes(char)) {
                    const last = stack.pop();
                    if (!last || brackets[last.char] !== char) {
                        issues.push({
                            severity: 'error',
                            description: `Unmatched ${char} at position ${i}`,
                            fix: null
                        });
                    }
                }
            }
        }
        
        if (stack.length > 0) {
            stack.forEach(item => {
                issues.push({
                    severity: 'error',
                    description: `Unmatched ${item.char} at position ${item.pos}`,
                    fix: null
                });
            });
        }

        // Check for trailing commas in JSON mode
        if (this.currentMode === 'json') {
            const trailingCommaRegex = /,(\s*[}\]])/g;
            let match;
            while ((match = trailingCommaRegex.exec(input)) !== null) {
                issues.push({
                    severity: 'warning',
                    description: `Trailing comma at position ${match.index}`,
                    fix: () => {
                        const fixed = input.replace(trailingCommaRegex, '$1');
                        this.inputEditor.value = fixed;
                        this.handleInput({ target: this.inputEditor });
                    }
                });
            }
        }

        return issues;
    }

    autoFixJSON(input) {
        let fixed = input;
        
        // Remove trailing commas
        fixed = fixed.replace(/,(\s*[}\]])/g, '$1');
        
        // Fix single quotes to double quotes (basic)
        fixed = fixed.replace(/'([^'\\]*(\\.[^'\\]*)*)'/g, '"$1"');
        
        // Add quotes around unquoted keys (basic)
        fixed = fixed.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');
        
        return fixed;
    }

    formatJavaScript(obj) {
        if (typeof obj === 'string') return `"${obj}"`;
        if (typeof obj === 'number' || typeof obj === 'boolean') return String(obj);
        if (obj === null) return 'null';
        if (obj === undefined) return 'undefined';
        
        if (Array.isArray(obj)) {
            const items = obj.map(item => this.formatJavaScript(item));
            return `[\n  ${items.join(',\n  ')}\n]`;
        }
        
        if (typeof obj === 'object') {
            const pairs = Object.entries(obj).map(([key, value]) => 
                `${key}: ${this.formatJavaScript(value)}`
            );
            return `{\n  ${pairs.join(',\n  ')}\n}`;
        }
        
        return String(obj);
    }

    highlightSyntax(code) {
        if (typeof code !== 'string') return code;
        
        return code
            .replace(/"([^"\\]*(\\.[^"\\]*)*)"/g, '<span class="string">"$1"</span>')
            .replace(/\b(-?\d+\.?\d*)\b/g, '<span class="number">$1</span>')
            .replace(/\b(true|false)\b/g, '<span class="boolean">$1</span>')
            .replace(/\bnull\b/g, '<span class="null">null</span>')
            .replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1<span class="key">$2</span>:')
            .replace(/([{}[\],:])/g, '<span class="punctuation">$1</span>');
    }

    updateStats() {
        const lines = this.currentInput.split('\n').length;
        const chars = this.currentInput.length;
        const bytes = new Blob([this.currentInput]).size;
        
        this.lineCount.textContent = lines;
        this.charCount.textContent = chars;
        this.issueCount.textContent = this.issues.length;
        this.fileSize.textContent = this.formatBytes(bytes);
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + sizes[i];
    }

    setStatus(type, text) {
        this.statusDot.className = `status-dot ${type}`;
        this.statusText.textContent = text;
    }

    updateIssues() {
        if (this.issues.length === 0) {
            this.issuesList.innerHTML = '<div style="color: var(--text-muted); text-align: center; padding: 1rem;">No issues detected</div>';
            this.applyAllBtn.disabled = true;
            return;
        }

        const fixableIssues = this.issues.filter(issue => issue.fix);
        this.applyAllBtn.disabled = fixableIssues.length === 0;

        this.issuesList.innerHTML = this.issues.map((issue, index) => `
            <div class="issue-item">
                <div class="issue-header">
                    <span class="issue-severity ${issue.severity}">${issue.severity.toUpperCase()}</span>
                </div>
                <div class="issue-description">${issue.description}</div>
                <div class="issue-actions">
                    ${issue.fix ? `<button class="btn" onclick="app.applyFix(${index})">Apply Fix</button>` : ''}
                    <button class="btn" onclick="app.dismissIssue(${index})">Dismiss</button>
                </div>
            </div>
        `).join('');
    }

    applyFix(index) {
        if (this.issues[index] && this.issues[index].fix) {
            this.issues[index].fix();
            this.issues.splice(index, 1);
            this.updateIssues();
            this.updateStats();
        }
    }

    dismissIssue(index) {
        this.issues.splice(index, 1);
        this.updateIssues();
        this.updateStats();
    }

    applyAllFixes() {
        const fixableIssues = this.issues.filter(issue => issue.fix);
        fixableIssues.forEach(issue => issue.fix());
        this.issues = this.issues.filter(issue => !issue.fix);
        this.updateIssues();
        this.updateStats();
    }

    clearInput() {
        this.inputEditor.value = '';
        this.currentInput = '';
        this.outputContent.textContent = 'Ready...';
        this.issues = [];
        this.updateStats();
        this.updateIssues();
        this.updateLineNumbers('input');
        this.setStatus('ready', 'Ready');
    }

    formatCode() {
        if (!this.currentInput.trim()) return;
        
        try {
            let formatted;
            if (this.currentMode === 'json') {
                const parsed = JSON.parse(this.autoFixJSON(this.currentInput));
                formatted = JSON.stringify(parsed, null, 2);
            } else {
                // Basic JavaScript formatting
                const func = new Function('return ' + this.currentInput);
                const result = func();
                formatted = this.formatJavaScript(result);
            }
            
            this.inputEditor.value = formatted;
            this.handleInput({ target: this.inputEditor });
        } catch (error) {
            this.showFeedback('Format failed: ' + error.message, 'error');
        }
    }

    copyOutput() {
        const text = this.outputContent.textContent;
        navigator.clipboard.writeText(text).then(() => {
            this.showFeedback('Copied to clipboard!', 'success');
        }).catch(() => {
            this.showFeedback('Copy failed', 'error');
        });
    }

    showFeedback(message, type) {
        const feedback = document.createElement('div');
        feedback.className = 'copy-feedback';
        feedback.textContent = message;
        document.body.appendChild(feedback);
        
        setTimeout(() => {
            feedback.remove();
        }, 2000);
    }

    handleFileUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        this.readFile(file);
        e.target.value = ''; // Clear input
    }

    readFile(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            this.inputEditor.value = e.target.result;
            this.handleInput({ target: this.inputEditor });
            
            // Auto-detect mode based on file extension or content
            if (file.name.endsWith('.json') || this.looksLikeJSON(e.target.result)) {
                this.switchMode('json');
            } else if (file.name.endsWith('.js')) {
                this.switchMode('javascript');
            }
        };
        reader.readAsText(file);
    }

    looksLikeJSON(content) {
        const trimmed = content.trim();
        return (trimmed.startsWith('{') && trimmed.endsWith('}')) ||
               (trimmed.startsWith('[') && trimmed.endsWith(']'));
    }

    handleDragOver(e) {
        e.preventDefault();
    }

    handleDragEnter(e) {
        e.preventDefault();
        this.dropZone.classList.add('active');
    }

    handleDragLeave(e) {
        if (!e.relatedTarget || !document.contains(e.relatedTarget)) {
            this.dropZone.classList.remove('active');
        }
    }

    handleDrop(e) {
        e.preventDefault();
        this.dropZone.classList.remove('active');
        
        const files = Array.from(e.dataTransfer.files);
        const validFile = files.find(file => 
            file.type === 'application/json' || 
            file.name.endsWith('.json') || 
            file.name.endsWith('.js') || 
            file.name.endsWith('.txt')
        );
        
        if (validFile) {
            this.readFile(validFile);
        }
    }

    toggleSection(e) {
        const header = e.currentTarget;
        const section = header.dataset.section;
        const content = document.getElementById(section + 'Content');
        const isCollapsed = content.classList.contains('collapsed');
        
        content.classList.toggle('collapsed', !isCollapsed);
        header.querySelector('span:last-child').textContent = isCollapsed ? '−' : '+';
    }
}

// Initialize the application
const app = new JSONJSCorrector();